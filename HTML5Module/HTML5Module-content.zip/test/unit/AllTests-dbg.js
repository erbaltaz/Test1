sap.ui.define([
	"ns/HTML5Module/test/unit/controller/Test_View1.controller"
], function () {
	"use strict";
});
